'use client'

export default function Page() {
  return (
    <div className="container mx-auto px-4 py-8 text-center">
      <h1 className="text-lg font-semibold mb-2">You are in the queue</h1>
      <p>Please try again in a few minutes.</p>
    </div>
  )
}
